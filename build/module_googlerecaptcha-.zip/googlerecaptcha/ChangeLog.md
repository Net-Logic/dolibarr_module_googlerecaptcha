
## v2.0.0 (2025-10-23)

#### :rocket: Enhancement
* [#5](https://github.com/Net-Logic/dolibarr_module_googlerecaptcha/pull/5) min dolibarr version is 19 ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#1](https://github.com/Net-Logic/dolibarr_module_googlerecaptcha/pull/1) last fix ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
